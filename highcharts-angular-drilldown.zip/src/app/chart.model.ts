class Chart {
    Product: string;
    Product_Category: string;
    Price_Range: string;
    Store_Number: any;
    Number_of_items_sold: any;

    constructor(
    ){
        this.Product=""
        this.Product_Category = ""
        this.Price_Range= ""
        this.Store_Number=""
        this.Number_of_items_sold = ""

    }
}

export default Chart;