import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoredrillComponent } from './storedrill.component';

describe('StoredrillComponent', () => {
  let component: StoredrillComponent;
  let fixture: ComponentFixture<StoredrillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoredrillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoredrillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
