import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, OnInit, ViewChild, ElementRef, VERSION } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Component } from '@angular/core';
import * as  Highcharts from 'highcharts';
import More from 'highcharts/highcharts-more';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
// Load the exporting module.
import Exporting from 'highcharts/modules/exporting';
// Initialize exporting module.
Exporting(Highcharts);
import { ChartService } from '../app.service';
import Chart from '../chart.model';
import { HashTable } from 'angular-hashtable';

@Component({
  selector: 'app-storedrill',
  templateUrl: './storedrill.component.html',
  styleUrls: ['./storedrill.component.css']
})
export class StoredrillComponent implements OnInit {

  private drillMap = new Map();
  private drillSales: Array<number>;
  private storeNumber: any;
  private salesList:any;
  private chartList: Chart[];
  constructor(private chartService: ChartService) {
    this.drillSales = [];
    this.storeNumber = [];
    this.salesList = [];
  }

  ngOnInit() {
    this.getData();
    Highcharts.chart('container', {
      chart: {
        type: 'column',
      },
      title: {
        text: 'Highcharts multi-series drilldown'
      },
      subtitle: {
        text: 'Click columns to drill down to single series. Click categories to drill down both.'
      },
      xAxis: {
        title: 'Product Category',
        type: 'category'
      },

      plotOptions: {
        series: {
          borderWidth: 0,
          dataLabels: {
            enabled: true
          }
        }
      },
      series: [{
        name: 'Super Market Sales',
        data: [
          {
            name: this.storeNumber[0],
            y: this.salesList[0],
            drilldown: this.storeNumber[0]
          },
          { name: this.storeNumber[1], y: this.salesList[1], drilldown: true },
          { name: this.storeNumber[2], y: this.salesList[2], drilldown: true },
        ]
      }],
      drilldown: {
        series: [{
          name: this.storeNumber[0],
          id: this.storeNumber[0],
          data: [
            ['Win 7', 55.03],
            ['Win XP', 15.83],
            ['Win Vista', 3.59],
            ['Win 8', 7.56],
            ['Win 8.1', 6.18]
          ]
        }],
      },
    })
  }

  getData() {
    this.chartList = this.chartService.getsales();
    for (let item of this.chartList) {
      let value = item.Store_Number;
      if (this.drillMap.has(item.Store_Number) == true) {
        this.drillMap.set(item.Store_Number, value + this.drillMap.get(item.Store_Number));
      }
      else {
        this.drillMap.set(item.Store_Number, item.Number_of_items_sold);
      }
    }
    Array.from(this.drillMap.keys()).forEach(value => this.storeNumber.push(value));
    Array.from(this.drillMap.values()).forEach(value => this.salesList.push(value));
    console.log(this.drillMap);
  }

}