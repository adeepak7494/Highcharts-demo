import { Observable } from 'rxjs/Rx';
import Chart from './chart.model';
import { Injectable } from '@angular/core';

//RxJS operator for mapping the observable

import 'rxjs/add/operator/map';

@Injectable()
export class ChartService {
    private Total_sales: Chart[] = [
            {
              "Product": "Book",
              "Product_Category": "Stationary",
              "Price_Range": "20-30",
              "Store_Number": 2,
              "Number_of_items_sold": 30
            },
            {
              "Product": "Pen",
              "Product_Category": "Stationary",
              "Price_Range": "0-10",
              "Store_Number": 3,
              "Number_of_items_sold": 20
            },
            {
              "Product": "Banana",
              "Product_Category": "Fruits",
              "Price_Range": "20-30",
              "Store_Number": 1,
              "Number_of_items_sold": 10
            },
            {
              "Product": "Apple",
              "Product_Category": "Fruits",
              "Price_Range": "90-100",
              "Store_Number": 2,
              "Number_of_items_sold": 12
            },
            {
              "Product": "carrot",
              "Product_Category": "Vegetables",
              "Price_Range": "40-50",
              "Store_Number": 3,
              "Number_of_items_sold": 50
            },
            {
              "Product": "Book",
              "Product_Category": "Stationary",
              "Price_Range": "20-30",
              "Store_Number": 3,
              "Number_of_items_sold": 20
            },
            {
              "Product": "Book",
              "Product_Category": "Stationary",
              "Price_Range": "20-30",
              "Store_Number": 1,
              "Number_of_items_sold": 34
            },
            {
              "Product": "Pen",
              "Product_Category": "Stationary",
              "Price_Range": "0-10",
              "Store_Number": 2,
              "Number_of_items_sold": 45
            },
            {
              "Product": "Pen",
              "Product_Category": "Stationary",
              "Price_Range": "0-10",
              "Store_Number": 1,
              "Number_of_items_sold": 56
            },
            {
              "Product": "Banana",
              "Product_Category": "Fruits",
              "Price_Range": "20-30",
              "Store_Number": 2,
              "Number_of_items_sold": 34
            },
            {
              "Product": "Banana",
              "Product_Category": "Fruits",
              "Price_Range": "20-30",
              "Store_Number": 3,
              "Number_of_items_sold": 45
            },
            {
              "Product": "Plums",
              "Product_Category": "Fruits",
              "Price_Range": "20-30",
              "Store_Number": 2,
              "Number_of_items_sold": 10
            },
            {
              "Product": "Peach",
              "Product_Category": "Fruits",
              "Price_Range": "90-100",
              "Store_Number": 3,
              "Number_of_items_sold": 45
            },
            {
              "Product": "Tape",
              "Product_Category": "Stationary",
              "Price_Range": "0-10",
              "Store_Number": 1,
              "Number_of_items_sold": 34
            }
    ];
    constructor() { }
    getsales(): Chart[] {
        return this.Total_sales;
    }
}