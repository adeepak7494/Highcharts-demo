import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';
import {ChartService} from './app.service';
import { Routes, RouterModule, Router } from "@angular/router";


import { NgbModule, NgbButtonsModule } from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { PricedrillComponent } from './pricedrill/pricedrill.component';
import { StoredrillComponent } from './storedrill/storedrill.component';

const routes: Routes = [
  { path: "", redirectTo: "home", pathMatch: "full" },
  { path: "home", component: AppComponent },
  { path: "pricerange", component: PricedrillComponent },
  { path: "storenumber", component:StoredrillComponent},
  { path: "**", component: AppComponent }
];

@NgModule({
  imports:      [ BrowserModule, FormsModule,HttpModule,NgbModule,NgbButtonsModule,
    JsonpModule,  RouterModule.forRoot(routes, { useHash: true }) ],
  providers: [ChartService],
  declarations: [ AppComponent, PricedrillComponent, StoredrillComponent ],
  bootstrap:    [ AppComponent ],
})
export class AppModule { 

}
