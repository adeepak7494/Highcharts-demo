import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, OnInit, ViewChild, ElementRef, VERSION } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Component } from '@angular/core';
import * as  Highcharts from 'highcharts';
import More from 'highcharts/highcharts-more';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
// Load the exporting module.
import Exporting from 'highcharts/modules/exporting';
// Initialize exporting module.
Exporting(Highcharts);
import { ChartService } from '../app.service';
import Chart from '../chart.model';
import { HashTable } from 'angular-hashtable';

@Component({
  selector: 'app-pricedrill',
  templateUrl: './pricedrill.component.html',
  styleUrls: ['./pricedrill.component.css']
})
export class PricedrillComponent implements OnInit {

  private drillMap = new Map();
  private drillSales: Array<number>;
  private priceRange: any;
  private salesList:any;
  private chartList: Chart[];
  constructor(private chartService: ChartService) {
    this.drillSales = [];
    this.priceRange = [];
    this.salesList = [];
  }

  ngOnInit() {
    this.getData();
    Highcharts.chart('container', {
      chart: {
        type: 'column',
      },
      title: {
        text: 'Highcharts multi-series drilldown'
      },
      subtitle: {
        text: 'Click columns to drill down to single series. Click categories to drill down both.'
      },
      xAxis: {
        title: 'Product Category',
        type: 'category'
      },

      plotOptions: {
        series: {
          borderWidth: 0,
          dataLabels: {
            enabled: true
          }
        }
      },
      series: [{
        name: 'Super Market Sales',
        data: [
          {
            name: this.priceRange[0],
            y: this.salesList[0],
            drilldown: this.priceRange[0]
          },
          { name: this.priceRange[1], y: this.salesList[1], drilldown: true },
          { name: this.priceRange[2], y: this.salesList[2], drilldown: true },
        ]
      }],
      drilldown: {
        series: [{
          name: this.priceRange[0],
          id: this.priceRange[0],
          data: [
            ['Win 7', 55.03],
            ['Win XP', 15.83],
            ['Win Vista', 3.59],
            ['Win 8', 7.56],
            ['Win 8.1', 6.18]
          ]
        }],
      },
    })
  }

  getData() {
    this.chartList = this.chartService.getsales();
    for (let item of this.chartList) {
      let value = item.Number_of_items_sold;
      if (this.drillMap.has(item.Price_Range) == true) {
        this.drillMap.set(item.Price_Range, value + this.drillMap.get(item.Price_Range));
      }
      else {
        this.drillMap.set(item.Price_Range, item.Number_of_items_sold);
      }
    }
    Array.from(this.drillMap.keys()).forEach(value => this.priceRange.push(value));
    Array.from(this.drillMap.values()).forEach(value => this.salesList.push(value));
    console.log(this.drillMap);
  }

}

