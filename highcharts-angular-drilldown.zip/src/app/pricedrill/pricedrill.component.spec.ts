import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricedrillComponent } from './pricedrill.component';

describe('PricedrillComponent', () => {
  let component: PricedrillComponent;
  let fixture: ComponentFixture<PricedrillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricedrillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricedrillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
