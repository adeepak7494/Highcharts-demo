import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, OnInit, ViewChild, ElementRef, VERSION } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Component } from '@angular/core';
import * as  Highcharts from 'highcharts';
import More from 'highcharts/highcharts-more';
More(Highcharts);
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
// Load the exporting module.
import Exporting from 'highcharts/modules/exporting';
// Initialize exporting module.
Exporting(Highcharts);
import { ChartService } from './app.service';
import Chart from './chart.model';
import { HashTable } from 'angular-hashtable';
import {Router} from "@angular/router";


@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})
export class AppComponent implements OnInit {
  // // name = `Angular! v${VERSION.full}`;
  // @ViewChild("container", { read: ElementRef }) container: ElementRef;

  private chartList: Chart[];
  private map = new Map();
  private salesList: any;
  private productList: any;


  constructor(private chartService: ChartService, private router:Router) {
    this.salesList = [];
    this.productList = [];

  }
  ngOnInit() {
    this.getData();
    Highcharts.chart('container', {
      chart: {
        type: 'column',
      },
      title: {
        text: 'Highcharts multi-series drilldown'
      },
      subtitle: {
        text: 'Click columns to drill down to single series. Click categories to drill down both.'
      },
      xAxis: {
        type: 'category'
      },

      plotOptions: {
        series: {
          borderWidth: 0,
          dataLabels: {
            enabled: true
          }
        }
      },
      series: [{
        name: 'Super Market Sales',
        data: [
          {
            name: this.productList[0],
            y: this.salesList[0],
            drilldown: this.productList[0]
          },
          { name: this.productList[1], y: this.salesList[1], drilldown: true },
          { name: this.productList[2], y: this.salesList[2], drilldown: true },
        ]
      }],
      drilldown: {
        series: [{
          name: this.productList[0],
          id: this.productList[0],
          data: [
            ['Win 7', 55.03],
            ['Win XP', 15.83],
            ['Win Vista', 3.59],
            ['Win 8', 7.56],
            ['Win 8.1', 6.18]
          ]
        }],
      },
    })
  }

  loadPriceDrill()
  {
    this.router.navigate(['/pricerange']);
  }

  loadStoreDrill(){
    this.router.navigate(['/storenumber']);
  }
  getData()
  {
    this.chartList = this.chartService.getsales();
    for (let item of this.chartList) {
      let value = item.Number_of_items_sold;
      if (this.map.has(item.Product_Category) == true) {
        this.map.set(item.Product_Category, value + this.map.get(item.Product_Category));
      }
      else {
        this.map.set(item.Product_Category, value);
      }
    }
    console.log(this.map);
    Array.from(this.map.values()).forEach(value => this.salesList.push(value));
    Array.from(this.map.keys()).forEach(value => this.productList.push(value));
  }
}